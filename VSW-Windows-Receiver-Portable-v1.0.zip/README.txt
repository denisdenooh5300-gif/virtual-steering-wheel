Virtual Steering Receiver — current VSW Android app

This receiver matches the VSW Android app's version-1 UDP protocol (app package
com.auram.virtualswpad.guide, app version 3.2). It listens on UDP 45678.

CONTENTS AND REQUIREMENTS
- Run VirtualSteeringReceiver-240fps.exe on the Windows PC.
- Keep QRCoder.dll, ViGEmClient.dll, receiver-logo.png, and receiver-icon.png beside the EXE.
- The VSW steering-wheel logo is embedded as the Windows app icon and used by the tray icon.
- Install/run ViGEmBus on Windows for the virtual Xbox controller to appear.
- The installer does not install third-party drivers. Install ViGEmBus separately
  from its official project if you need virtual Xbox controller emulation.
- Allow the receiver through Windows Firewall on the active Private network.
  Do not disable the firewall. Run only one receiver instance at a time.
- Minimize the receiver or close its window to keep it running in the system
  tray. Double-click the tray icon to restore it; right-click for Open, Start
  with Windows, and Exit. Start with Windows is an optional per-user setting.
- The phone app remembers the receiver IP/port. On app launch it opens Home and
  starts its receiver probe automatically; the PC must be awake and reachable.

APP FEATURES HANDLED
- Automatic UDP discovery and manual receiver-IP entry; reports the Android
  device name and returns receiver acknowledgements.
- Main-pad steering, pedals, look-around, handbrake, gears, and mapped buttons.
- Walk-pad left-stick movement, right-stick aiming, face buttons, triggers,
  bumpers, menu/view, sprint, and D-pad mapped to an Xbox 360 controller.
- Virtual-mouse relative movement, one/two-finger click, vertical/horizontal
  scrolling, and three-finger Windows desktop/Task View gestures.
- Optional PC desktop capture returned as VSWF/JPEG UDP frames at the app's
  requested 15/30/60/120/240 FPS and 480p/720p/1080p/4K target.
- Telemetry return packet for speed, RPM, gear, damage, and haptic level.

CONNECTION
Connect the phone and PC to a network that allows local UDP traffic. The QR
code now prefers the active PC adapter with an IPv4 gateway (for example, the
phone-facing USB-tether adapter) instead of a virtual adapter. Let the app
discover the receiver first. If needed, enter the PC's current reachable IPv4
address and port 45678 manually; the address can change between Wi-Fi and USB
tethering. Avoid guest Wi-Fi/client isolation. The receiver window's device
list and connection status show received app packets.

STREAMING AND TELEMETRY NOTES
The app and receiver currently exchange JPEG frames split into UDP packets;
this is not an H.264/HEVC hardware-encoder pipeline and cannot promise 5 ms or
Sunshine/Moonlight-level latency. 120 FPS/4K are requested limits, not a
guarantee; capture speed, PC display resolution, network, and phone refresh
rate constrain actual performance. The 240 FPS option requests a 4.17 ms
capture interval, but this software GDI/JPEG pipeline and the phone's display
refresh may deliver fewer unique frames. Higher resolutions can increase latency.

Game telemetry uses the SCS Telemetry SDK shared-memory map. Euro Truck
Simulator 2 / American Truck Simulator must have a compatible SCS telemetry
plugin installed and running for live game speed/RPM/gear/damage data. Desktop
streaming and controller input do not depend on that plugin. Other games will
not provide those telemetry values unless they expose a compatible data source.

TROUBLESHOOTING
- Only one receiver process can own UDP 45678. A second launch now reports
  which port is in use; close the other receiver copy before starting another.
- If the controller is absent, install/restart ViGEmBus and then reopen the
  receiver.
- If the phone remains disconnected, confirm both devices are on the same
  reachable LAN, allow the Private-network firewall prompt, and enter the PC's
  current IPv4 address manually.
- receiver-debug.log is written beside the EXE for startup/network diagnostics.
